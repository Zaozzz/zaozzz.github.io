'use strict';
window.nativeCall=async(action,args={})=>{
 if(!window.webkit?.messageHandlers?.native)throw new Error('请在 PersonalOS macOS 应用中打开此界面。');
 try{return await window.webkit.messageHandlers.native.postMessage({action,args});}
 catch(e){if(String(e.message||e).includes('LOCKED')){window.desktopLock?.();throw new Error('工作区已锁定。');}throw new Error(String(e.message||e));}
};
let resolvePOS;
window.POSReady=new Promise(resolve=>{resolvePOS=resolve;});
window.desktopLock=()=>{document.querySelector('#desktop').hidden=true;document.querySelectorAll('dialog[open]').forEach(d=>d.close());document.querySelector('#lockScreen').hidden=false;document.querySelector('#lockMessage').textContent='工作区已锁定。资料保留在本机。';document.querySelector('#unlockButton').hidden=false;};
(async()=>{
 const show=state=>{window.__desktopState=state;document.querySelector('#lockScreen').hidden=true;document.querySelector('#desktop').hidden=false;if(window.POSWork){window.POSWork.replace(state);window.dispatchEvent(new CustomEvent('desktop-state',{detail:state}));}else resolvePOS(state);};
 document.querySelector('#unlockButton').onclick=async()=>{const b=document.querySelector('#unlockButton');b.disabled=true;try{show(await window.nativeCall('unlock'));document.querySelector('#lockError').textContent='';}catch(e){document.querySelector('#lockError').textContent=e.message;}finally{b.disabled=false;}};
 try{const ready=await window.nativeCall('ready');if(ready.locked)window.desktopLock();else show(await window.nativeCall('state'));}catch(e){document.querySelector('#lockMessage').textContent=e.message;}
 let last=0;for(const event of ['pointerdown','keydown','scroll'])document.addEventListener(event,()=>{if(Date.now()-last>30000&&!document.querySelector('#desktop').hidden){last=Date.now();window.nativeCall('heartbeat').catch(()=>{});}},{passive:true,capture:true});
})();
